The goal of the game is to destroy the spider spawn points.

Green is health
Blue is Focus (gained by killing spiders)
Costs 25% focus to use a special ability (unlocked at level 2)

Controls:
WASD - Move around
Left/Right Mouse - Fire primary/secondary Weapon
Spacebar - Use special ability
q - Switch primary weapon
e - Switch secondary weapon
f - Switch special ability

Other Controls:
Esc - Quit
r - Pause
u - Fullscreen (no you can't get out of fullscreen... MWUAHAHAHA)
Arrow Keys - Look around
PgUp/PgDn - Zoom
1 - Skip level (don't do it cheater!)